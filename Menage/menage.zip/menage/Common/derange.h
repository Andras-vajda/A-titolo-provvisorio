/*************************************************************************
**************************************************************************
**                                                                      **
**  PROGRAMMA......:  derange.h                                         **
**  VERSIONE.......:  1.0                                               **
**  AUTORE.........:  M.A.W. 1968                                       **
**  LICENZA........:  Public Domain                                     **
**  DATA...........:  22/08/2015            Ore 00:35                   **
**                                                                      **
**  Descrizione....:  Header comune per le implementazioni di           **
**                    test dei vari algoritmi combinatori.              **
**                                                                      **
**************************************************************************
*************************************************************************/

#ifndef __DERANGE_H__
#define __DERANGE_H__

#include <stdio.h>
#include <stdlib.h>
#include <assert.h>
#include <string.h>
#include "binom.h"

#define DERANGE_WIDTH    5
#define MAX_DERANGE     10

#define H_SEP_STAR "************************************************************"
#define H_SEP_LINE "------------------------------------------------------------"

typedef struct {
    uint8_t     Width;          /* Ampiezza del derangement               */
    derange_t   D[MAX_DERANGE]; /* Contiene il derangement vero e proprio */
    derange_t  *Tree;           /* Alberi binari per l'algoritmo di       */
    derange_t  *BTree;          /* Mikawa-Tanaka                          */
    size_t      Nodes;          /* Numero di nodi dell'albero BTree       */
    size_t      Layers;         /* Profondita' del BTree                  */
} Derange_MT;

/* Tabella del numero di derangements in funzione di n */
static const unsigned int De[] = {1, 0, 1, 2, 9, 44, 265, 1854, 14833, 133496, 1334961};

#endif
/* EOF: derange.h */
/*************************************************************************
**************************************************************************
**                                                                      **
**  PROGRAMMA......:  dtypes.c                                          **
**  VERSIONE.......:  1.0                                               **
**  AUTORE.........:  M.A.W. 1968                                       **
**  LICENZA........:  Public Domain                                     **
**  DATA...........:  22/08/2015            Ore 00:35                   **
**                                                                      **
**  Descrizione....:  Tipi UDT condivisi per le implementazioni di      **
**                    test dei vari algoritmi combinatori.              **
**                    Incluso da binom.h                                **
**************************************************************************
*************************************************************************/

#ifndef __DTYPES_H__
#define __DTYPES_H__

typedef unsigned int        uint_t;
typedef unsigned char       uint8_t;
typedef unsigned char       derange_t;
typedef enum {FALSE, TRUE}  Boole_t;

#endif
/* EOF: dtypes.h */
/*************************************************************************
**************************************************************************
**                                                                      **
**  PROGRAMMA......:  binom.h                                           **
**  VERSIONE.......:  1.0                                               **
**  AUTORE.........:  M.A.W. 1968                                       **
**  LICENZA........:  Public Domain                                     **
**  DATA...........:  22/08/2015            Ore 00:35                   **
**                                                                      **
**  Descrizione....:  Header comune per le implementazioni di           **
**                    test dei vari algoritmi combinatori.              **
**                    Incluso da derange.h                              **
**************************************************************************
*************************************************************************/

#ifndef __BINOM_H__
#define __BINOM_H__

#include "dtypes.h"

#if defined(__GNUC__)
 int min(const int a, const int b);
 int max(const int a, const int b);
 /*const char Compiler[] = "** Compiled with GNU C/C++"
                         "                                **";*/
#endif

#if defined(__TURBOC__) || defined(__BORLANDC__)
 #include <mem.h>

 int min(const int a, const int b);

 #pragma warn -csu
 #pragma warn -sig

 /*const char Compiler[] = "** Compiled with Borland C++"
                         "                              **";*/
#endif

/* Restituisce il coefficiente binomiale n su k.                        */
uint_t BinCoef(const int n, int k);

/* Logaritmo binario veloce.                                            */
uint8_t log_2(unsigned int v);

/* Stampa un oggetto combinatorio.                                      */
void DisplayVector(size_t len, derange_t *A, char *lead, char *trail,
                   char *sep);

/* Potenza del due immediatamente superiore al valore dato.             */
uint8_t nlpo2(uint_t x);

/* Limite pratico per il coefficiente binomiale */
#define MAX_BIN 35

#endif
/* EOF: binom.h */
/*************************************************************************
**************************************************************************
**                                                                      **
**  PROGRAMMA......:  Misc_MT.c                                         **
**  AUTORE.........:  M.A.W. 1968                                       **
**  LICENZA........:  Public Domain                                     **
**  DATA...........:  22/08/2015            Ore 00:35                   **
**  VERSIONE.......:  1.0                                               **
**                                                                      **
**  Descrizione....:  Funzioni di supporto a Derange_MT.c               **
**                                                                      **
**************************************************************************
*************************************************************************/

#include "derange.h"

extern Derange_MT Derange;

/************************************************************************/
/************************************************************************/
/* Funzioni accessorie:                                                 */
void TreeInit(void);
void TreeClean(void);

/* Calcola il vettore di inversione "classico", riferito ai lavori      */
/* di Marshall Hall, in tempo O(nlog2(n)).                              */
void Knuth_rank(derange_t *b);

/* Calcola il vettore di inversione Lehmer, o factoradic, in O(n^2).    */
/* Presentata come contrappasso dantesco a Knuth_rank(), costituisce un */
/* ottimo esempio di Pessima Programmazione e della legge di Gresham.   */
void Lehmer_rank(derange_t *b);

/************************************************************************/
/************************************************************************/

/************************************************************************/
/* Calcola il vettore di inversione "classico", riferito ai lavori      */
/* di Marshall Hall, in tempo O(nlog2(n)).                              */
/* Basato sostanzialmente sull'esercizio 5.1.1-6 del TAoCP, vol. 3, al  */
/* quale si deve anche la nomenclatura b, B, c, C per le varianti piu'  */
/* diffuse di inversion vector.                                         */
/************************************************************************/
void Knuth_rank(derange_t *b)
{
    size_t j;
    int k;
    uint8_t r, s;
    derange_t x[MAX_DERANGE];

    memset(b, 0, Derange.Width * sizeof(derange_t));

    for (k = log_2(Derange.Width); k >= 0; --k)
    {
        for (s = 0; s <= (Derange.Width >> (k+1)); ++s)
        {
            x[s] = 0;
        }

        for (j = 0; j < Derange.Width; ++j)
        {
            r = 1 & (Derange.D[j] >> k);
            s = Derange.D[j] >> (k +1);

            if (r & 1)
            {
                x[s] += 1;
            }
            else
            {
                b[Derange.D[j]] += x[s];
            }
        }
    }

    for (j = 0; j < Derange.Width; ++j)
    {
        x[j] = b[Derange.D[j]];
    }

    DisplayVector(Derange.Width, b, "", " ", "");
    DisplayVector(Derange.Width, x, "", " ", "");
}

/************************************************************************/
/* Calcola il vettore di inversione Lehmer, o factoradic, in O(n^2).    */
/* Presentata come contrappasso dantesco a Knuth_rank(), costituisce un */
/* ottimo esempio di Pessima Programmazione e della legge di Gresham.   */
/*                                                                      */
/* Algoritmo naive non meno del bubblesort, e come esso pervasivamente  */
/* diffuso e terribilmente inefficiente, attira ad un tempo dilettanti  */
/* e practitioners con una regolarita' sinistramente impressionante,    */
/* ad onta dell'esistenza da decenni di algoritmi tree-based in tempo   */
/* O(nlog2(n)) atti a svolgere il medesimo compito - per non dire di    */
/* codifiche assai piu' efficienti computazionalmente come gray, plain  */
/* changes (aka bell ringing), etc.                                     */
/************************************************************************/
void Lehmer_rank(derange_t *b)
{
    size_t in = 0, j;
    int k;
    derange_t x[MAX_DERANGE];

    memset(b, 0, Derange.Width * sizeof(derange_t));

    for (j = 0; j < Derange.Width; ++j)
    {
        for (k = j +1; k < Derange.Width; ++k)
        {
            b[j] += (Derange.D[k] < Derange.D[j]) ? 1 : 0;
        }
        x[Derange.D[j]] = b[j];
        in += b[j];
    }

    DisplayVector(Derange.Width, b, " ", " ", "");
    DisplayVector(Derange.Width, x, "", " ", "");
    printf("%2d ", in);
}

/************************************************************************/
/* Funzione di supporto per TM_derange().                               */
/* Inizializza gli alberi binari per l'algoritmo di Mikawa-Tanaka.      */
/************************************************************************/
void TreeInit(void)
{
    int i, m;
    derange_t v, k;

    /*
    ** Il limite superiore per k e' ovviamente funzione del valore
    ** definito per MAX_DERANGE.
    */
    k = log_2(nlpo2(Derange.Width));

    /* 
    ** Si predispone un albero binario con k+1 livelli e 2^(k+1) -1 nodi. 
    ** La variabile k qui risulta di una unita' inferiore rispetto alla lambda
    ** teorica, per ridurre la complessita' ciclomatica e semplificare
    ** il codice nei due layer estremi, guadagnando anche in robustezza.
    */
    Derange.Layers = k;
    Derange.Nodes = (1 << (k +1)) -1;

    /* L'albero e' efficientissimamente emulato tramite un binary heap array. */
    Derange.Tree = (derange_t *)malloc(Derange.Nodes * sizeof(derange_t));
    if (NULL == Derange.Tree)
    {
        fprintf(stderr, "ERRORE di allocazione dell'albero binario \"Tree\"\n\n");
        exit(1);
    }

    /*
    ** Raddoppiando l'occupazione di memoria si ottiene la possibilita' di
    ** reinizializzare l'array alla massima velocita', con una banale memcpy(),
    ** evitando l'uso di nested loop e/o di eccessiva aritmetica degli indici.
    ** L'albero va inizializzato ad ogni chiamata della routine di
    ** conversione del vettore di inversione, ossia n!/e volte, dunque il
    ** guadagno e' molto rilevante anche per piccoli valori di n.
    */
    Derange.BTree = (derange_t *)malloc(Derange.Nodes * sizeof(derange_t));
    if (NULL == Derange.BTree)
    {
        fprintf(stderr, "ERRORE di allocazione dell'albero binario \"BTree\"\n\n");
        exit(1);
    }

    /* L'albero viene adeguatamente popolato con i valori richiesti. */
    v = 1 << k;
    m = 0;
    for (i = 0; i <= k; v >>= 1, ++i)
    {
        int j;
        for (j = 0; j < (1 << i); ++j)
        {
            Derange.Tree[m++] = v;
        }
    }
}

/************************************************************************/
/* Funzione di supporto per TM_derange().                               */
/************************************************************************/
void TreeClean(void)
{
    free(Derange.BTree);
    free(Derange.Tree);
}

/* EOF: misc_MT.c */

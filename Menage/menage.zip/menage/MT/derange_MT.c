/*************************************************************************
**************************************************************************
**                                                                      **
**  PROGRAMMA......:  Derange_MT.c                                      **
**  AUTORE.........:  M.A.W. 1968                                       **
**  LICENZA........:  Public Domain                                     **
**  DATA...........:  22/08/2015            Ore 00:35                   **
**  VERSIONE.......:  1.0                                               **
**                                                                      **
**  Descrizione....:  Originale implementazione di un algoritmo per la  **
**                    generazione esaustiva di derangements.            **
**************************************************************************
**                                                                      **
** Si tratta di un recentissimo lavoro di Mikawa & Tanaka,              **
** basato su un albero binario e su un algoritmo di ranking             **
** delle inversioni innovativo rispetto alla classica e poco efficiente **
** numerazione fattoradica (codifica Lehmer) ed a tutti i suoi          **
** succedanei.                                                          **
**                                                                      **
** Kenji Mikawa, Ken Tanaka, "Lexicographic Ranking and Unranking of    **
** Derangements in Cycle Notation", Discrete Applied Mathematics 166    **
** (2014) 164-169.                                                      **
**                                                                      **
**************************************************************************
*************************************************************************/

#include "derange_MT.h"

#define VERBOSE

/************************************************************************/
/************************************************************************/
int main(void)
{
    size_t i;

    Derange.Width = DERANGE_WIDTH;

    assert(Derange.Width < MAX_DERANGE);

    /************************************************************************/
#ifdef VERBOSE
    printf("\nDerangements di %d (%lu), algoritmo di Mikawa-Tanaka:\n",
           Derange.Width, De[Derange.Width]);

    puts(" Ra Inv    # Cycle Derangement  b-inv B-inv c-inv C-inv ##\n"
         "---------------------------------------------------------------");
#endif

    TreeInit();

    for (i = 0; i < De[Derange.Width]; ++i)
    {
 #ifdef VERBOSE
        printf("%3d ", i);
 #endif
        /* Implementazione dell'algoritmo di Mikawa e Tanaka */
        TM_unrank(i);
    }
 #ifdef VERBOSE
    printf("** Totale: %ld **\n", i);
 #endif

    TreeClean();

    return EXIT_SUCCESS;
}

/************************************************************************/
/* Algoritmo di unranking Mikawa-Tanaka, suddiviso su due funzioni      */
/* TM_rank2in() e TM_inv2cycles() per massima chiarezza espositiva.     */
/* Le sezioni di visualizzazione sono state qui separate adeguatamente  */
/* dal codice di elaborazione, sempre ai fini della chiarezza.          */
/************************************************************************/
void TM_unrank(const uint_t rank)
{
    /*
    ** Variabile automatica ridondante, per pura uniformita' di
    ** notazione con l'articolo.
    */
    size_t n = Derange.Width;

    int i;
    derange_t m;

#ifdef VERBOSE
    /* Numero di inversioni */
    size_t in;
#endif

    /* Vettore di inversione */
    derange_t v[MAX_DERANGE];

    /* Derangement in notazione ciclica */
    derange_t cy[MAX_DERANGE];

    TM_rank2inv(rank, v);

#ifdef VERBOSE
    /* Visualizzazione del vettore di inversione */
    in = 0;
    for (i = 0; i < n; ++i)
    {
        in += v[i];
    }
    DisplayVector(n, v, "", " ", "");
    printf("%2d ", in);
#endif

    TM_inv2cycles(v, cy);

    /*
    ** Conversione da cycle notation a one-line.
    ** Vale la pena di notare che gli autori utilizzano nell'articolo una
    ** "standard notation" la quale sfortunatamente differisce sia dalla
    ** notazione standard ideata da Stanley (peraltro citato dagli stessi
    ** autori), sia dall'alternativa usata da Knuth.
    */
    m = cy[n -1];
    i = n -2;
    while (i > -1)
    {
        if(cy[i] < m)
        {
            Derange.D[m] = cy[i +1];
            m = cy[i];
        }
        else
        {
            Derange.D[cy[i]] = cy[i +1];
        }
        --i;
    }
    Derange.D[m] = cy[i +1];

#ifdef VERBOSE
    /* Visualizzazione notazione ciclica, priva di parentesi */
    DisplayVector(n, cy, "", " ", "");
    /* Visualizzazione del derangement, one-line */
    DisplayVector(n, Derange.D, "", " ", "");
    printf("(%3ld) ", TM_rank(cy));
    Knuth_rank(v);
    Lehmer_rank(v);
    puts("");
#endif
}

/************************************************************************/
/* Algoritmo di unranking Mikawa-Tanaka, step 1:                        */
/* converte un rank in un vettore di inversione.                        */
/************************************************************************/
void TM_rank2inv(const uint_t rank, derange_t *v)
{
    /*
    ** Variabile automatica ridondante, per pura uniformita' di
    ** notazione con l'articolo.
    */
    size_t n = Derange.Width;

    size_t i, x, x1;

    /*
    ** La prima cifra del vettore di inversione e' sicuramente
    ** non nulla, l'ultima e' nulla per definizione.
    ** Cio' consente di semplificare le condizioni iniziali
    ** rispetto alle formule riportate (con qualche errore) nell'articolo.
    ** I tre valori di inversione in posizione 0, 1 ed n-1
    ** vengono facilmente assegnati fuori dal loop.
    */
    v[n -1] = 0;
    v[0] = 1 + rank / (De[n -1] + De[n -2]);
    x = rank - (v[0] -1) * (De[n -1] + De[n -2]);
    if (x < De[n -2])
    {
        v[1] = 0;
    }
    else
    {
        v[1] = 1 + (x - De[n -2])/(De[n -2] + De[n -3]);
    }
    /*
    ** Le formulette fornite consentono di ricavare ogni elemento
    ** del vettore di inversione da una semplice terna di valori,
    ** in tempo costante, incluso il precedente valore di Xi.
    ** Tale valore viene qui salvato in x1 per ogni passo successivo.
    */
    x1 = x;

    for (i = 2; i < n -1; ++i)
    {
        /* Si ricava innanzi tutto il rank parziale Xi, grazie a x1 */
        if ((v[i -1] != 0) && (v[i -2] != 0))
        {
            x = x1 - (v[i -1] -1)*(De[n -i] + De[n -i -1]) -De[n-i];
        }
        else if (v[i -1] == 0)
        {
            x = x1;
        }
        else if (v[i -2] == 0)
        {
            x = x1 - (v[i -1] -1)*(De[n -i] + De[n -i -1]);
        }
        x1 = x;

        /* Da tale rank si passa facilmente al numero di inversioni. */
        if (0 == v[i -1])
        {
            v[i] = 1 + (x / (De[n -i -1] + De[n -i -2]));
        }
        else if ((0 != v[i -1]) && (x < De[n -i -1]))
        {
            v[i] = 0;
        }
        else
        {
            v[i] = 1 + (x - De[n -i -1]) / (De[n -i -1] + De[n -i -2]);
        }
    }
}

/************************************************************************/
/* Algoritmo di unranking Mikawa-Tanaka, step 2:                        */
/* converte un vettore di inversione in un derangement, espresso in     */
/* notazione ciclica, usando un albero binario.                         */
/************************************************************************/
void TM_inv2cycles(derange_t *v, derange_t *cy)
{
    /*
    ** Variabile automatica ridondante, per pura uniformita' di
    ** notazione con l'articolo.
    */
    size_t n = Derange.Width;

    size_t i;

    /* Inizializzazione per copia. */
    memcpy(Derange.BTree, Derange.Tree, Derange.Nodes * sizeof(derange_t));

    for (i = 0; i < n; ++i)
    {
        size_t j = 0;
        size_t le;

        /* Visita top-down del BTree. */
        for (le = 0; le < Derange.Layers; ++le)
        {
            /* Decrementa il valore al nodo corrente. */
            Derange.BTree[j] -= 1;
            if(v[i] < Derange.BTree[1 + (j << 1)])
            {
                /* Visita il figlio a SINISTRA. */
                j = 1 + (j << 1);
            }
            else
            {
                /*
                ** Sottrae da v[i] il valore del figlio SINISTRO,
                ** poi visita il figlio a DESTRA.
                */
                v[i] -= Derange.BTree[1 + (j << 1)];
                j = 2 + (j << 1);
            }
        }
        /* 
        ** Decrementa anche il valore della foglia, per mera coerenza,
        ** sebbene a rigore non sia necessario.
        */
        Derange.BTree[j] -= 1;
        /* Assegna alla locazione corrente l'attributo della foglia. */
        cy[i] = j - ((1 << (Derange.Layers)) -1);
    }
}

/************************************************************************/
/* Algoritmo di ranking Mikawa-Tanaka.                                  */
/* NB: Il derangement cy deve essere espresso in notazione ciclica.     */
/************************************************************************/
uint_t TM_rank(derange_t *cy)
{
    /*
    ** Variabile automatica ridondante, per pura uniformita' di
    ** notazione con l'articolo.
    */
    size_t n = Derange.Width;
    size_t i;

    uint_t ra = 0L;
    derange_t v[MAX_DERANGE];

    memset(Derange.BTree, 0, Derange.Nodes * sizeof(derange_t));
    memcpy(v, cy, MAX_DERANGE * sizeof(derange_t));

    /* Conversione del derangement (cycle) in vettore di inversione. */
    for (i = 0; i < n; ++i)
    {
        size_t j = cy[i] + ((1 << Derange.Layers) -1);
        size_t le;

        /* Visita bottom-up del BTree. */
        for (le = 0; le < Derange.Layers; ++le)
        {
            /* Incrementa il valore al nodo corrente. */
            Derange.BTree[j] += 1;
            /*
            ** Se si tratta del figlio DESTRO, sottrae da v[i] il valore
            ** contenuto nel figlio SINISTRO.
            */
            if(0 == (j & 1))
            {
                v[i] -= Derange.BTree[j -1];
            }
            /* Visita il padre. */
            j = (j -1) >> 1;
        }
    }

    /* Calcolo del rank dal vettore di inversione. */
    ra += (v[0] -1)*(De[n -1] + De[n -2]);
    for (i = 1; i < n; ++i)
    {
        if (v[i] != 0)
        {
            ra += (v[i] -1)*(De[n -i -1] + De[n -i -2]);
            if(v[i -1] != 0)
            {
                ra += De[n -i -1];
            }
        }
    }

    return ra;
}
/* EOF: Derange_MT.c */

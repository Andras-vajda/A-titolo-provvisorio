/*************************************************************************
**************************************************************************
**                                                                      **
**  PROGRAMMA......:  Derange_MT.h                                      **
**  AUTORE.........:  M.A.W. 1968                                       **
**  LICENZA........:  Public Domain                                     **
**  DATA...........:  22/08/2015            Ore 00:35                   **
**  VERSIONE.......:  1.0                                               **
**                                                                      **
**  Descrizione....:  Header privato per Derange_MT.c                   **
**                                                                      **
**************************************************************************
*************************************************************************/

#ifndef __DERANGE_MT_H__
#define __DERANGE_MT_H__

#include "derange.h"

/************************************************************************/
/* Variabili globali */
Derange_MT Derange;
/************************************************************************/

/************************************************************************/
/************************************************************************/
/* Funzioni accessorie in misc_MT.c                                     */
extern void TreeInit(void);
extern void TreeClean(void);

/* Calcola il vettore di inversione "classico", riferito ai lavori      */
/* di Marshall Hall, in tempo O(nlog2(n)).                              */
extern void Knuth_rank(derange_t *b);

/* Calcola il vettore di inversione Lehmer, o factoradic, in O(n^2).    */
/* Presentata come contrappasso dantesco a Knuth_rank(), costituisce un */
/* ottimo esempio di Pessima Programmazione e della legge di Gresham.   */
extern void Lehmer_rank(derange_t *b);
/************************************************************************/
/************************************************************************/
/* Algoritmo di unranking Mikawa-Tanaka, suddiviso su due funzioni      */
/* TM_rank2in() e TM_inv2cycles() per massima chiarezza espositiva.     */
void TM_unrank(const uint_t rank);

/* Algoritmo di unranking Mikawa-Tanaka, step 1:                        */
/* converte un rank un in vettore di inversione.                        */
void TM_rank2inv(const uint_t rank, derange_t *v);

/* Algoritmo di unranking Mikawa-Tanaka, step 2:                        */
/* converte un vettore di inversione in un derangement, espresso in     */
/* notazione ciclica, usando un albero binario.                         */
void TM_inv2cycles(derange_t *v, derange_t *cy);

/* Algoritmo di ranking Mikawa-Tanaka.                                  */
/* NB: Il derangement cy deve essere espresso in notazione ciclica.     */
uint_t TM_rank(derange_t *cy);
/************************************************************************/
/************************************************************************/

#endif
/* EOF: Derange_MT.h */
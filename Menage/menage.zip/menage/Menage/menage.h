/*************************************************************************
**************************************************************************
**                                                                      **
**  PROGRAMMA......:  Menage2.c                                         **
**  AUTORE.........:  M.A.W. 1968                                       **
**  LICENZA........:  Public Domain                                     **
**  DATA...........:                        Ore                         **
**  VERSIONE.......:  1.0                                               **
**                                                                      **
**  Descrizione....:  Header privato di menage2.c                       **
**                                                                      **
**************************************************************************
*************************************************************************/

#ifndef __MENAGE_H__
#define __MENAGE_H__

#include <stdio.h>
#include <stdlib.h>
#include <assert.h>
#include <string.h>

#if defined(__TURBOC__) || defined(__BORLANDC__)
 #include <mem.h>

 #pragma warn -csu
 #pragma warn -sig

 /*const char Compiler[] = "** Compiled with Borland C++"
                         "                              **";*/
#endif

/*************************************************************************/
/*************************************************************************/

typedef unsigned int            uint_t;
typedef unsigned char           uint8_t;
typedef enum {FALSE, TRUE}       Boole_t;
/*
** Con taluni compilatori si ottiene una maggiore velocita'
** usando unsigned int, se si accetta il tradeoff con la compattezza.
*/
typedef unsigned char           derange_t;

#define COUPLES     4

/*
** Lo chef sconsiglia *vivamente* di modificare il seguente valore.
** Si ricordi inoltre che l'implementazione usa volutamente putchar()
** per la stampa di ogni singolo elemento del vettore, quindi non e'
** possibile gestire piu' di dieci coppie senza modifiche al sorgente.
*/
#define MAX_COUPLES 5

#define MAX_FACT    10

/*************************************************************************/
/* Tipici cognomi francesi: un tocco di folklore non guasta.             */
/*************************************************************************/
const char Surnomes[][10] = {
"Andre", "Bernard", "Bertrand", "Bonnet", "David","Dubois",
"Dupont", "Durand", "Fournier", "Francois", "Garcia", "Garnier",
"Girard", "Lambert", "Laurent", "Lefebvre", "Lefevre", "Legrand",
"Leroy", "Martin", "Martinez", "Mercier", "Michel", "Moreau",
"Morel", "Petit", "Richard", "Robert", "Roux", "Simon", "Thomas",
"Vincent"};

const uint_t fact[] = {1, 1, 2, 6, 24, 120, 720, 5040, 40320, 362880, 3628800};
const uint_t Touchard[] = {0, 0, 0, 1, 2, 13, 80, 579, 4738, 43387, 439792};

/*************************************************************************/
/*************************************************************************/

void Knuth_X(void);
void Rohl_derange(const char len);
void Akl_derange(const char len);

Boole_t CheckMenage(void);
void Perm2Cycle(derange_t *d);
void SolveMenage(void);
void DisplayMenage(derange_t *A);

/*************************************************************************/
/* Variabili globali                                                     */
/*************************************************************************/
struct {
    uint8_t     Width;              /* Ampiezza del derangement               */
    derange_t   D[MAX_COUPLES];     /* Contiene il derangement corrente       */
    derange_t   We[MAX_COUPLES];    /* Array dei pesi per l'algoritmo di Rohl */
    size_t      Cnt, Tot, Sol;
} Derange;

#endif
/* EOF: Menage.h */

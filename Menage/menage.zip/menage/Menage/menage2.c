/*************************************************************************
**************************************************************************
**                                                                      **
**  PROGRAMMA......:  Menage2.c                                         **
**  AUTORE.........:  M.A.W. 1968                                       **
**  LICENZA........:  Public Domain                                     **
**  DATA...........:                        Ore                         **
**  VERSIONE.......:  1.0                                               **
**                                                                      **
**  Descrizione....:  Esempio di risoluzione esaustiva al problema dei  **
**  menages, per piccoli valori di n, come discusso sul blog.           **
**                                                                      **
**************************************************************************
*************************************************************************/

#include "menage.h"

/*************************************************************************/
/*************************************************************************/
int main(void)
{
    size_t i;

    /* Numero di coppie */
    Derange.Width = COUPLES;

    assert(Derange.Width < MAX_COUPLES);

    Derange.Cnt   = 0L;
    Derange.Sol   = 0L;
    Derange.Tot   = Touchard[Derange.Width];

    for (i = 0; i < Derange.Width; ++i)
    {
        Derange.D[i]  = i;
        Derange.We[i] = 1;
    }

    printf(">> Problema dei menages:\n"
           ">> esempio didattico di procedura risolutiva esaustiva per %d coppie.\n"
           ">> Si hanno in totale %ld derangements e %ld soluzioni.\n\n",
           Derange.Width, Derange.Tot,
           (Derange.Tot << 1) * fact[Derange.Width]);

    /*
    ** STEP 1:
    ** Si generano tutti e soli i derangements validi, ossia invarianti
    ** rispetto ad una rotazione DX di una posizione.
    */
    Knuth_X();
    /*
    ** In alternativa, come omaggio della Casa, sono implementati anche:
    ** Rohl_derange(0);
    ** Akl_derange(Derange.Width);
    */

    printf(">> Generati in totale %ld derangements e %ld soluzioni.\n\n",
           Derange.Cnt, Derange.Sol);

    return EXIT_SUCCESS;
}

/************************************************************************/
/* Algoritmo X di Knuth (7.2.1.2, Vol. IV fasc. A1 p. 334 del TAOCP):   */
/* "Lexicographic Permutations with Restricted Prefixes", da un'idea di */
/* M.C. Er (pubblicata nel 1987).                                       */
/*                                                                      */
/* Implementazione ispirata alla versione C++ di Joerg Arndt (FXT).     */
/************************************************************************/
void Knuth_X(void)
{
    derange_t P[MAX_COUPLES];
    derange_t Links[MAX_COUPLES];
    derange_t Undo[MAX_COUPLES];

    size_t k;
    derange_t p, q;

    /* X1. [Initialize.] */
    for (k = 0; k < Derange.Width; ++k)
    {
        Links[k] = k + 1;
    }
    Links[Derange.Width] = 0;
    k = 1;

    /* X2. [Enter level k.] */
X2:
    p = 0;
    q = Links[0];

    /* X3. [test (P[1], ..., P[k])] */
X3:
    P[k] = q -1;

    if ((q == k) || (q == 1 + (k % Derange.Width)))
    {
        goto X5;
    }
    else if (k == Derange.Width)
    {
        /* Per uniformita' con le funzioni alternative: */
        memcpy(Derange.D, P+1, Derange.Width * sizeof(derange_t));
        /*
        ** STEP 2 e 3:
        ** Sono ovviamente implementati a parte, per ogni derangement
        ** valido generato.
        */
        SolveMenage();
        goto X6;
    }

    /* X4. [Increase k.] */
    Undo[k]  = p;
    Links[p] = Links[q];
    ++k;
    goto X2;

    /* X5. [Increase P[k].] */
X5:
    p = q;
    q = Links[p];
    if (q != 0)
    {
        goto X3;
    }

    /* X6. [Decrease k.] */
X6:
    --k;
    if (0 == k)
    {
        return;
    }
    p = Undo[k];
    q = P[k] +1;
    Links[p] = q;
    goto X5;
}

/************************************************************************/
/* Algoritmo ricorsivo di Rohl (1978) riveduto e semplificato.          */
/*                                                                      */
/* I derangement condizionati sono qui prodotti con una early           */
/* reject condition, associata alla if() gia' presente strutturalmente  */
/* entro l'inner loop: caratteristica assai comune in molti algoritmi   */
/* dell'epoca, a maggior ragione nei piu' generici e flessibili.        */
/* Non ultimo tra questi lo stesso Heap, impiegato poco oltre - in      */
/* versione iterativa, per l'occasione.                                 */
/*                                                                      */
/* L'eleganza e la concisione di questi algoritmi ne giustificano       */
/* comunque ancor oggi l'impiego didattico e illustrativo.              */
/************************************************************************/
void Rohl_derange(const char len)
{
    if (len == Derange.Width)
    {
        SolveMenage();
    }
    else
    {
        size_t i;
        for (i = 0; i < Derange.Width; ++i)
        {
            if ((Derange.We[i] == 1) &&
                (len != i) &&
                (((len +1) % Derange.Width) != i))
            {
                Derange.D[len] = i;
                Derange.We[i]--;
                Rohl_derange(len +1);
                Derange.We[i]++;
            }
        }
    }
}

/************************************************************************/
/* Algoritmo ricorsivo classico di Akl (1981) per i derangements.       */
/*                                                                      */
/* Il derangement corrente viene qui convalidato come "menage"          */
/* solo al termine della generazione.                                   */
/* In compenso, qui non vi sono salti nell'inner loop.                  */
/* Complessivamente le prestazioni di questa implementazione            */
/* restano solo leggermente inferiori a quelle di Rohl_derange()        */
/* in termini di derangements al secondo, specialmente per              */
/* piccoli valori di ampiezza.                                          */
/*                                                                      */
/************************************************************************/
void Akl_derange(const char len)
{
    if (0 == len)
    {
        if (CheckMenage())
        {
            SolveMenage();
        }
    }
    else
    {
        int j;
        /*
        ** Calcolo del valore iniziale di j in funzione del vincolo
        ** fondamentale per i derangements.
        */
        j = ((len -1) == Derange.D[len -1]) ? (len -2) : (len -1);
        for (; j >= 0; --j)
        {
            unsigned int t;

            /* SWAP d[j], d[len] */
            t = Derange.D[j];
            Derange.D[j] = Derange.D[len -1];
            Derange.D[len -1] = t;

            Akl_derange(len - 1);

            /* SWAP d[j], d[len] */
            t = Derange.D[j];
            Derange.D[j] = Derange.D[len -1];
            Derange.D[len -1] = t;
        }
    }
}

/************************************************************************/
/*
** STEP 2:
** PER OGNI derangement valido generato, si generano TUTTE le permutazioni
** dell'ordine degli invitati.
**
** L'algoritmo iterativo qui impiegato e' essenzialmente derivato
** dall'algoritmo (ricorsivo) di Heap seguendo le indicazioni del
** Sedgewick.
*/
/************************************************************************/
void SolveMenage(void)
{
    /* Array per la permutazione dell'ordine degli invitati */
    derange_t Couples[MAX_COUPLES];
    /* Array ausiliario dei pesi per le permutazioni */
    derange_t w[MAX_COUPLES];
    /* Totalizzatore delle permutazioni generate */
    size_t cnt = 1;

    size_t i;

    Derange.Cnt += 1;
    printf("> Derangement %d su %ld: (", Derange.Cnt, Derange.Tot);
    for (i = 0; i < Derange.Width; ++i)
    {
        putchar(Derange.D[i] +'0');
    }
    puts(")");

    /*
    ** Stampa della permutazione identita', fuori dal loop.
    ** Per le permutazioni delle coppie si usa l'alfabeto minuscolo
    ** {a, b, c, ...} in fase di stampa, per maggiore chiarezza.
    */
    printf("  > Permutazione %d su %d: (", cnt, fact[Derange.Width]);
    for (i = 0; i < Derange.Width; ++i)
    {
        w[i] = 0;
        Couples[i] = i;
        putchar(Couples[i] + 'a');
    }
    puts(")");
    DisplayMenage(Couples);

    for (i = 0; i < Derange.Width;)
    {
        if (w[i] < i)
        {
            derange_t tmp, k;

            k = (i & 1) * w[i];

            /* SWAP P[i], P[(i & 1) * w[i]] */
            tmp     = Couples[i];
            Couples[i] = Couples[k];
            Couples[k] = tmp;

            /*
            ** STEP 3:
            ** Si stampa la lista degli invitati con assegnazione dei posti.
            */
            ++cnt;
            printf("  > Permutazione %d su %d: (", cnt, fact[Derange.Width]);
            for (k = 0; k < Derange.Width; ++k)
            {
                putchar(Couples[k] + 'a');
            }
            puts(")");
            DisplayMenage(Couples);

            w[i]++;
            i = 0;
        }
        else
        {
            w[i++] = 0;
        }
    }
}

/******************************************************************************/
/*
** STEP 3:
** Si stampa la lista degli invitati (e il suo duale) con assegnazione dei posti.
** I posti dispari (risp. signore e poi signori) saranno assegnati
** linearmente, leggendo i cognomi secondo la permutazione corrente.
** I posti pari (risp. signori o signore) saranno assegnati
** seguendo il derangement generato al passo 1, ottenendo quindi la
** garanzia di rispetto del vincolo fondamentale del problema.
** Tale convenzione e' puramente arbitraria e ininfluente sulla soluzione,
** per ovvia simmetria.
*/
/******************************************************************************/
void DisplayMenage(derange_t *A)
{
    size_t i;


    printf("    > Soluzione %ld (priorita' alle Signore):\n", ++Derange.Sol);
    for (i = 0; i < Derange.Width; ++i)
    {
        printf("    >> %2d %s %-10s   %2d %s %-10s\n",
               1+(i<<1), "M.me", Surnomes[A[i]],
               2+(i<<1), "Msr.", Surnomes[A[Derange.D[i]]]);
    }
    puts("\n");

    printf("    > Soluzione %ld (priorita' ai Signori):\n", ++Derange.Sol);
    for (i = 0; i < Derange.Width; ++i)
    {
        printf("    >> %2d %s %-10s   %2d %s %-10s\n",
               1+(i<<1), "Msr.", Surnomes[A[i]],
               2+(i<<1), "M.me", Surnomes[A[Derange.D[i]]]);
    }
    puts("\n");
}

/************************************************************************/
/*
** Routine ausiliaria per Akl_derange: stabilisce in tempo lineare
** se il derangement corrente rimane tale a seguito di una
** rotazione a destra.
*/
/************************************************************************/
Boole_t CheckMenage(void)
{
    size_t i;

    if (0 == Derange.D[Derange.Width -1])
    {
        return FALSE;
    }

    for(i = 1; i < Derange.Width; ++i)
    {
        if (Derange.D[i-1] == i)
        {
            return FALSE;
        }
    }

    return TRUE;
}

/************************************************************************/
/* Bonus: visualizza una permutazione in cycle notation.                */
/* Fa uso di una bitmap per l'insieme dei valori gia' assegnati.        */
/************************************************************************/
void Perm2Cycle(derange_t *d)
{
    uint_t bmap = 0;
    uint8_t j;

    for (j = 0; j < Derange.Width; ++j)
    {
        if(0 == (bmap & (1 << j)))
        {
            uint8_t next = j;
            putchar('(');
            do
            {
                putchar(next + '0');
                bmap |= (1 << next);
            } while (j != (next = d[next]));
            putchar(')');
        }
    }
    putchar(' ');
}
/* EOF: menage2.c */

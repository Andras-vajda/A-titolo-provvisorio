/*************************************************************************
**************************************************************************
**                                                                      **
**  PROGRAMMA......:  Menage.c                                          **
**  AUTORE.........:  M.A.W. 1968                                       **
**  LICENZA........:  Public Domain                                     **
**  DATA...........:                        Ore                         **
**  VERSIONE.......:  1.0                                               **
**                                                                      **
**  Descrizione....:  Elementare proof of concept per la generazione di **
**  una singola soluzione al problema dei menages, come discusso sul    **
**  blog.                                                               **
**                                                                      **
**************************************************************************
*************************************************************************/

#include <stdio.h>
#include <stdlib.h>
#include <time.h>

#define MAX_COUPLES 32U

typedef unsigned int uint_t;
typedef enum {FALSE, TRUE} Boole_t;

char Surnomes[][10] = {
"Andre", "Bernard", "Bertrand", "Bonnet", "David","Dubois",
"Dupont", "Durand", "Fournier", "Francois", "Garcia", "Garnier",
"Girard", "Lambert", "Laurent", "Lefebvre", "Lefevre", "Legrand",
"Leroy", "Martin", "Martinez", "Mercier", "Michel", "Moreau",
"Morel", "Petit", "Richard", "Robert", "Roux", "Simon", "Thomas",
"Vincent"};

/*************************************************************************/
/*************************************************************************/

void shuffle(uint_t places[])
{
    /*
    ** Array per l'estrazione di un numero random univoco.
    */
    uint_t Shrink[MAX_COUPLES];
    uint_t i, asize;

    for (i = 0; i < MAX_COUPLES; ++i)
    {
        Shrink[i] = i;
    }

    /*
    ** Si genera una permutazione dei primi MAX_COUPLES
    ** naturali nell'array passato come parametro.
    */
    asize = MAX_COUPLES;
    for (i = 0; i < MAX_COUPLES; ++i)
    {
        uint_t pos;

        pos = rand() % asize;
        places[i] = Shrink[pos];
        --asize;
        Shrink[pos] = Shrink[asize];
    }
}

/*************************************************************************/
/*************************************************************************/

int main(void)
{
    uint_t i, offset;
    uint_t Chaises[MAX_COUPLES];
    time_t t;

    /*
    ** Per rendere minimamente interessante l'output, si
    ** parte da una permutazione pseudocasuale dei
    ** cognomi, invece di limitarci al banale ordine
    ** lessicografico.
    */
    srand((unsigned)time(&t));
    shuffle(Chaises);

    /*
    ** Si calcola l'offset, ossia il numero di sedie
    ** da interporre come "distanza di sicurezza"
    ** tra mariti e mogli... :-)
    */
    offset = 1 + (rand() % (MAX_COUPLES -2));

    /*
    ** G A M E   O V E R
    */
    for (i = 0; i < MAX_COUPLES; ++i)
    {
        printf("%2d Madame %-10s %2d Monsieur %-10s\n",
               2*i+1, Surnomes[Chaises[i]],
               2*i+2, Surnomes[Chaises[(i + offset) % MAX_COUPLES]]);
    }

    return (0);
}
/* EOF: Menage.c */
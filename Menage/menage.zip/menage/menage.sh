#!/bin/bash
echo ./menage2
./menage2>menage2.txt
echo ./derange_APR
./derange_APR
echo ./derange_ER
./derange_ER
echo ./derange_MT
./derange_MT
echo ./mr_perm
./mr_perm
WIDTH=4
while [ WIDTH -lt 9 ]; do
    ./hrw_gen $WIDTH
    ./hrw_dec perm0$WIDTH.dat>perm0$WIDTH.txt
    let WIDTH=WIDTH+1
done

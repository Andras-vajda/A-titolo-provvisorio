/*************************************************************************
**************************************************************************
**                                                                      **
**  PROGRAMMA......:  Derange_APR.c                                     **
**  AUTORE.........:  M.A.W. 1968                                       **
**  LICENZA........:  Public Domain                                     **
**  DATA...........:  22/08/2015            Ore 00:35                   **
**  VERSIONE.......:  1.0                                               **
**                                                                      **
**  Descrizione....:  Originale implementazione di un algoritmo per la  **
**                    generazione di derangements condizionati.         **
**************************************************************************
**                                                                      **
**  Si tratta del classico algoritmo ricorsivo di Rohl pubblicato nel   **
**  1978, modificato in una recente pubblicazione:                      **
**  P. Ganapathi & B. Rama, "A Versatile Algorithm to Generate Various  **
**  Combinatorial Structures", {arXiv:1009.4214v2}                      **
**                                                                      **
**************************************************************************
*************************************************************************/

#include "derange.h"

/*
** Disabilitare per eliminare l'output a video dei derangements.
*/
#define VERBOSE

/* Variabili globali */
struct derange {
    uint8_t     Width;                      /* Ampiezza del derangement    */
    derange_t   D[MAX_DERANGE];             /* Derangement                 */
    derange_t   CountArray[MAX_DERANGE];    /* Occorrenze del multiset     */
    derange_t   OrderSet[MAX_DERANGE];      /* Elementi unici del multiset */
    derange_t   List[MAX_DERANGE];          /* Il multiset esteso          */
    uint8_t     r;                          /* Solo prefissi se r < Width  */
} Derange;

/************************************************************************/
/************************************************************************/
/* Flavour di APR per la generazione dei derange                        */
uint_t APR_derange(const uint8_t len);

/************************************************************************/
/************************************************************************/
int main(void)
{
    size_t i;
    uint_t tot;

    /* Ampiezza del derangement */
    Derange.Width = DERANGE_WIDTH;
    assert(Derange.Width < MAX_DERANGE);

    /************************************************************************/
    printf("Algoritmo APR di Rohl-Ganapathi-Rama:\n"
           "1) Esempio di generazione dei derangements di %d (%lu)\n",
           Derange.Width, De[Derange.Width]);
    /************************************************************************/

    /* 
    ** Per permutazioni e derangements semplici, r coincide con Width.
    */
    Derange.r = Derange.Width;

    for(i = 0; i < Derange.Width; ++i)
    {
        Derange.List[i] = i + '0';
        Derange.OrderSet[i] = i + '0';
        Derange.CountArray[i] = 1;
    }

    /* Implementazione dell'algoritmo ricorsivo di Ganapathi-Rama */
    tot = APR_derange(0);

#ifdef VERBOSE
    printf("\n" H_SEP_STAR "\n** Totale: %lu **\n" H_SEP_STAR "\n", tot);
#endif

#if (DERANGE_WIDTH != 5)
    Derange.Width = 5;
    Derange.r = Derange.Width;
#endif

    /************************************************************************/
    printf("\n2) Derangements di %d (%lu) in ordine totalmente arbitrario:\n",
           Derange.Width, De[Derange.Width]);
    /************************************************************************/
    for(i = 0; i < Derange.Width; ++i)
    {
        Derange.List[i] = i + 'a';
        Derange.CountArray[i] = 1;
    }
    /*
    ** Orderset contiene gli elementi unici di List (in questo caso, tutti), 
    ** elencati una e una sola volta, nell'ordine desiderato per l'output.
    ** Qui si mostra un esempio di ordinamento arbitrario, difficile da 
    ** descrivere concisamente in forma chiusa.
    */
    Derange.OrderSet[0] = 'c';
    Derange.OrderSet[1] = 'b';
    Derange.OrderSet[2] = 'd';
    Derange.OrderSet[3] = 'e';
    Derange.OrderSet[4] = 'a';

    tot = APR_derange(0);

#ifdef VERBOSE
    printf("\n" H_SEP_STAR "\n** Totale: %lu **\n" H_SEP_STAR "\n", tot);
#endif

    /*
    ** Le locazioni di CountArray corrispondono a quelle di Orderset
    ** e specificano la molteplicita' di ciascun elemento OrderSet[i]
    ** nel multiset.
    ** Ad esempio, se si ha List[] = {'a','a','b','b','b','c','c'}:
    ** OrderSet[]   = {'c', 'a', 'b'} volendo un ordine arbitrario, e
    ** CountArray[] = {2, 2, 3}
    */

    return EXIT_SUCCESS;
}

/************************************************************************/
/* Algoritmo di Rohl in versione modificata da Ganapathi e Rama per     */
/* la generazione esaustiva di derangements.                            */
/************************************************************************/
uint_t APR_derange(const uint8_t len)
{
    size_t i;
    uint_t cnt = 0;

    if (len == Derange.r)
    {
#ifdef VERBOSE
        /* Attenzione alla peculiare gestione delle stampe! */
        for(i = 0; i < Derange.r; ++i)
        {
            putchar(Derange.D[i]);
        }
        putchar('\t');
#endif
        ++cnt;
    }
    else
    {
        for (i = 0; i < Derange.Width; ++i)
        {
            if ((Derange.CountArray[i] >= 1) &&
                (Derange.List[len] != Derange.OrderSet[i]))
            {
                Derange.D[len] = Derange.OrderSet[i];
                Derange.CountArray[i]--;
                cnt += APR_derange(len +1);
                Derange.CountArray[i]++;
            }
        }
    }

    return (cnt);
}
/* EOF: Derange_APR.c */

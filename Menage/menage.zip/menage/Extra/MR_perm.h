/*************************************************************************
**************************************************************************
**                                                                      **
**  PROGRAMMA......:  MR_Perm.h                                         **
**  AUTORE.........:  M.A.W. 1968                                       **
**  LICENZA........:  Public Domain                                     **
**  DATA...........:  22/08/2015            Ore 00:35                   **
**  VERSIONE.......:  1.0                                               **
**                                                                      **
**  Descrizione....:  Header privato di MR_Perm.c                       **
**                                                                      **
**************************************************************************
*************************************************************************/

#ifndef __MR_PERM_H__
#define __MR_PERM_H__

#include <stdio.h>
#include <stdlib.h>
#include <time.h>

/************************************************************************/
/* Dimensione delle permutazioni */
#define PERM_SIZE 6
/* Il fattoriale della dimensione appena definita */
#define PERM_SPACE 720
/* Numero di estrazioni pseudorandom desiderate */
#define NUM_EXTRACT 16
/************************************************************************/

/*
** Abilitare per output diagnostico avanzato
*/
//#define VERBOSE

/*
** Definire per generare TUTTE le permutazioni
*/
//#define EXHAUSTIVE

#ifdef VERBOSE
 #ifdef EXHAUSTIVE
  #undef EXHAUSTIVE
 #endif
#endif

#define H_SEP_STAR "************************************************************"
#define H_SEP_LINE "------------------------------------------------------------"

/************************************************************************/

typedef unsigned int    perm_t;

/************************************************************************/
/************************************************************************/
void Knuth_perm(size_t size, perm_t *pi);
void unrank(size_t size, size_t rank, perm_t *pi);
size_t rank(size_t size, perm_t *pi);
void init_perm(size_t size, perm_t *pi);
void print_perm(size_t size, size_t rank, perm_t *pi);

#endif
/* EOF: MR_perm.h */

/*************************************************************************
**************************************************************************
**                                                                      **
**  PROGRAMMA......:  MR_Perm.c                                         **
**  AUTORE.........:  M.A.W. 1968                                       **
**  LICENZA........:  Public Domain                                     **
**  DATA...........:  22/08/2015            Ore 00:35                   **
**  VERSIONE.......:  1.0                                               **
**                                                                      **
**  Descrizione....:  Originale implementazione didattica degli         **
**  algoritmi di ranking e unranking descritti da Frank Ruskey e        **
**  Wendy Myrvold in "Ranking and unranking permutations in linear      **
**  time."                                                              **
**  Come bonus, contiene anche l'algoritmo random shuffle               **
**  di Knuth, basato su range shrink.                                   **
**************************************************************************
*************************************************************************/

#include "MR_perm.h"

/************************************************************************/
/************************************************************************/
/*
** Array ausiliari per la routine di ranking,
** allocati staticamente nello heap per le migliori
** prestazioni.
*/
perm_t pii[PERM_SIZE];
perm_t ip[PERM_SIZE];
perm_t Aux[PERM_SIZE -2];

/************************************************************************/
/************************************************************************/
int main(void)
{
    /* Array che contiene la permutazione */
    perm_t pi[PERM_SIZE];
    size_t i;

    srand((unsigned)time(NULL));

#ifdef VERBOSE
    init_perm(PERM_SIZE, pi);
    puts(H_SEP_STAR);
    printf("> array[] = {%d", pi[0]);
    for (i = 1; i < PERM_SIZE; ++i)
    {
        printf(", %d", pi[i]);
    }
    puts("}");
    puts(H_SEP_STAR);
#endif

#ifdef EXHAUSTIVE
    for (i = 0; i < PERM_SPACE; ++i)
    {
        /*
        ** L'array DEVE essere reinizializzato prima di OGNI chiamata,
        ** per ottenere l'esatta sequenza descritta nel paper.
        */
        init_perm(PERM_SIZE, pi);
        unrank(PERM_SIZE, i, pi);
        printf("%3lu) ", i);
        print_perm(PERM_SIZE, rank(PERM_SIZE, pi), pi);
    }
#else
    puts(H_SEP_LINE);
    printf("Estrazione di %d permutazioni pseudocasuali di lunghezza %d\n"
           "con l'algoritmo di unranking Myrvold-Ruskey:\n",
           NUM_EXTRACT, PERM_SIZE);

    for (i = 0; i < NUM_EXTRACT; ++i)
    {
        size_t rnd = rand() % (PERM_SPACE -1);

        init_perm(PERM_SIZE, pi);
        unrank(PERM_SIZE, rnd, pi);
        printf("rank = %3lu, ", rnd);
        print_perm(PERM_SIZE, rank(PERM_SIZE, pi), pi);
    }

    puts(H_SEP_LINE);
    puts("Permutazioni agli estremi del range:");

    init_perm(PERM_SIZE, pi);
    unrank(PERM_SIZE, 0, pi);
    printf("rank =   0, ");
    print_perm(PERM_SIZE, 0, pi);

    init_perm(PERM_SIZE, pi);
    unrank(PERM_SIZE, PERM_SPACE -1, pi);
    printf("rank = %lu, ", PERM_SPACE -1);
    print_perm(PERM_SIZE, rank(PERM_SIZE, pi), pi);
    puts(H_SEP_LINE);

    init_perm(PERM_SIZE, pi);
    printf("Estrazione di %d permutazioni pseudocasuali di lunghezza %d\n"
           "con una variante dell'algoritmo di Knuth:\n",
           NUM_EXTRACT, PERM_SIZE);
    for (i = 0; i < NUM_EXTRACT; ++i)
    {
        /*
        ** Si ottiene un risultato interessante anche omettendo
        ** la seguente chiamata:
        ** init_perm(PERM_SIZE, pi);
        */
        Knuth_perm(PERM_SIZE, pi);
        printf("%2d - ", i+1);
        print_perm(PERM_SIZE, rank(PERM_SIZE, pi), pi);
    }
#endif
    puts(H_SEP_LINE);

    return 0;
}

/************************************************************************/
/* Shuffle di Knuth, modificato per operare in-place.                   */
/************************************************************************/
void Knuth_perm(size_t size, perm_t *pi)
{
    size_t i;

    for (i = size; i > 1; --i)
    {
        register perm_t t;
        size_t p = rand() % i;

        /* SWAP(pi[k-1], pi[rand(k)]) */
        t = pi[p];
        pi[p] = pi[i -1];
        pi[i -1] = t;
    }
}

/************************************************************************/
/* Unranking Myrvold-Ruskey                                             */
/************************************************************************/
void unrank(size_t size, size_t rank, perm_t *pi)
{
    size_t i;

    for (i = size; i > 0; --i)
    {
        register perm_t t, mod;
        mod = rank % i;

        /* SWAP(pi[n-1], pi[n%r]) */
        t = pi[i -1];
        pi[i -1] = pi[mod];
        pi[mod] = t;

        rank /= i;
    }
}

/************************************************************************/
/* Ranking Myrvold-Ruskey                                               */
/************************************************************************/
size_t rank(size_t size, perm_t *pi)
{
    size_t i, retval = 0;

    for (i = 0; i < size; ++i)
    {
        pii[i] = pi[i];
        ip[pi[i]] = i;
#ifdef VERBOSE
        printf("\n> pii[%d] = %d, ip[%d] = %d",
               i, pii[i], i, ip[i]);
#endif
    }
#ifdef VERBOSE
    puts("");
#endif

    for (i = size; i > 1; --i)
    {
        register perm_t s, t;

#ifdef VERBOSE
        size_t w1, k;
#endif
        s = pii[i-1];
        Aux[i -2] = s;

        /* swap(pii[n-1], pii[ip[n-1]])*/
        t = pii[i-1];
        pii[i-1] = pii[ip[i-1]];
        pii[ip[i-1]] = t;
#ifdef VERBOSE
        w1 = i -1;
        printf("\n> Aux[i-2] = %d, t = %d\n", s, t);
        printf("\n> a) swapping pii[%d] = %d with pii[%d] = %d\n",
               w1, pii[w1], ip[w1], pii[ip[w1]]);
#endif

        /* swap(ip[s], ip[n-1])*/
        t = ip[s];
        ip[s] = ip[i -1];
        ip[i -1] = t;
#ifdef VERBOSE
        printf("> b) swapping ip[%d] = %d with ip[%d] = %d\n",
               s, ip[s], w1, ip[w1]);

        printf("> c) pii[] = {%d", pii[0]);
        for (k = 1; k < size; ++k)
        {
            printf(", %d", pii[k]);
        }
        puts("}");
#endif
    }

    for (i = 2; i <= size; ++i)
    {
        retval = i * retval + Aux[i -2];
    }

#ifdef VERBOSE
    for (i = 0; i < size; ++i)
    {
        printf("\n> pii[%d] = %d",
               i, pii[i]);
    }
    puts("");
    printf("\n> ** retval = %d **\n", retval);
#endif

    return (retval);
}

/************************************************************************/
/* Inizializza la permutazione, come richiesto dall'algoritmo MR.       */
/************************************************************************/
void init_perm(size_t size, perm_t *pi)
{
    size_t i;
    for (i = 0; i < size; ++i)
    {
        pi[i] = i;
    }
}

/************************************************************************/
/* Stampa la permutazione e il relativo rank.                           */
/************************************************************************/
void print_perm(size_t size, size_t rank, perm_t *pi)
{
    size_t i;
    printf("P[rank] = {%d", pi[0]);
    for (i = 1; i < size; ++i)
    {
        printf(",%d", pi[i]);
    }
    printf("}, Rank(P) = %lu\n", rank);
}
/* EOF: MR_perm.c */

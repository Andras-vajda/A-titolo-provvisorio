/*************************************************************************
**************************************************************************
**                                                                      **
**  PROGRAMMA......:  HRW_gen.c                                         **
**  AUTORE.........:  M.A.W. 1968                                       **
**  LICENZA........:  Public Domain                                     **
**  DATA...........:  22/08/2015            Ore 00:35                   **
**  VERSIONE.......:  1.0                                               **
**                                                                      **
**  Descrizione....:  Originale implementazione dell'algoritmo di       **
**  Hollroyd, Ruskey e  Williams per la generazione di permutazioni     **
**  con ordinamento "BellRinger".                                       **
**                                                                      **
**  Compilato con la definizione TEST, produce le colonne e-j           **
**  (precedute dal rank 0..n!-1) della tabella 3 a pag. 26              **
**  dell'articolo "Shorthand Universal Cycles for Permutations"         **
**  di Holroyd, Ruskey & Williams.                                      **
**************************************************************************
*************************************************************************/

#include "hrw_gen.h"

/**************************************************************/
/**************************************************************/
int main(int argc, char **argv)
{
    BYTE perm_width;

    /* Impostazione del default */
    perm_width = PERM_SIZE;

    if (2 == argc)
    {
        BYTE t = (BYTE)atoi(argv[1]);
        if ((t >= PERM_MIN) && (t <= PERM_MAX))
        {
            perm_width = t;
        }
        else
        {
            fprintf(stderr, "Errore nel parametro da command line [%s]!\n"
                    "L'ampiezza assume il valore di default pari a "
                    xstr(PERM_SIZE) ".\n\n", argv[1]);
        }
    }

    BinaryBell(perm_width);

    return ERR_NONE;
}

/**************************************************************/
/*
** Stampa il valore binario di un intero, limitato
** agli n bit meno significativi.
*/
/**************************************************************/
void PrintBin(const size_t n, const size_t val)
{
    size_t mask;

    assert(n < 32);

    for (mask = 1 << (n -1); mask > 0; mask >>= 1)
    {
       printf("%c", (val & mask) ? '1' : '0');
    }
}
/**************************************************************/
/*
** Algoritmo di Holroyd-Ruskey-Williams in O(1)
** per la generazione del SP-Ciclo binario B(n)
** con ordinamento BellRinger.
*/
/**************************************************************/
void BinaryBell(const BYTE n)
{
#ifndef TEST
    /*
    ** Variabili relative alla creazione del file dati.
    ** Per praticita', il buffer risulta sbrigativamente
    ** preallocato in modo statico nello heap.
    */
    FILE *fp;
    BYTE bitofs;
    char fname[32];
    size_t idx, Words;
#else
    size_t i;
#endif

    /* Variabili ausiliarie per bit packing e altri task secondari */
    BYTE j;
    size_t psize, perms;

    psize = n -2;
    perms = 0;

#ifndef TEST
    bitofs = CHAR_BIT * sizeof(long);
    idx = 0;
    Words = 1;
#endif

    /* Inizializzazione come richiesto dall'algoritmo HRW */
    memset(A, 0, n);

    for (j = 0; j < n; ++j)
    {
        f[j] = (BYTE)j;
        D[j] = 1;
    }

    memset((void *)buff, 0, BUFF_SIZE * sizeof(long));

#ifdef TEST
    puts(H_SEP_STAR);
    puts("Compilato con l'opzione TEST, produce le colonne e-j\n"
         "(precedute dal rank 0..n!-1) della tabella 3 a pag. 26\n"
         "dell'articolo \"Shorthand Universal Cycles for Permutations\"\n"
         "di Holroyd, Ruskey & Williams.");
    puts(H_SEP_STAR);
#else
    sprintf(fname, "perm%02d.dat", n);
    printf("Codifica SP-Cycle delle permutazioni di ampiezza %d nel file \"%s\".\n",
           n, fname);

    fp = fopen(fname, "wb");
    if (NULL == fp)
    {
        fprintf(stderr, "Errore durante la creazione del file %s!\n", fname);
        exit(ERR_CREATE);
    }

    /*
    ** L'informazione relativa al numero di permutazioni non viene precalcolata.
    ** La relativa locazione nello header del file viene banalmente sovrascritta
    ** quando il dato richiesto diventa disponibile, a fine ciclo.
    */
    HRW_header.FingerPrint = FINGERPRINT + (n << 24);
    HRW_header.NumPerms = 0;
    if (1 != fwrite((void *)&HRW_header, sizeof(HRW_header), 1, fp))
    {
        fprintf(stderr, "Errore durante la scrittura sul file %s!\n", fname);
        fclose(fp);
        exit(ERR_WRITE);
    }
#endif

    do
    {
        size_t val;

        j = f[0];

#ifdef TEST
        printf("%3d ", perms);
        for (i = 0; i < n -1; ++i)
        {
            printf("%d", A[i]);
        }
        for (i = 0; i < n -1; ++i)
        {
            printf("%3d", D[i]);
        }
        putchar(' ');
        for (i = 0; i < n -1; ++i)
        {
            printf("%d", f[i] +1);
        }
        printf(" j = %d A[j] = %d ", j+1, A[j]);
#endif

        val = 1 << psize;

        if ((0 == A[j]) || (A[j] == (char)(psize -j)))
        {
            --val;
        }
        else if (1 == D[j])
        {
            val += (1 << (A[j] -1)) - (1 << (psize -j));
        }
        else
        {
            val += (1 << (psize -j -A[j] -1)) - (1 << (psize -j));
        }

        perms++;

#ifdef TEST
        PrintBin(n, val);
        printf(" (0x%02X)\n", val);
#else
        /* Bit packing */
        {
            short delta = (short)(bitofs - psize);
            bitofs = ((CHAR_BIT * sizeof(long) -1) & delta);

            if(delta < 0)
            {
                if (0 != bitofs)
                {
                    buff[idx] |= val >> -delta;
                }

                ++idx;
                ++Words;
                if (BUFF_SIZE == idx)
                {
                    if (1 != fwrite((void *)buff, idx * sizeof(long), 1, fp))
                    {
                        fprintf(stderr, "Errore durante la scrittura sul file %s!\n", fname);
                        fclose(fp);
                        exit(ERR_WRITE);
                    }
                    idx = 0;
                    memset((void *)buff, 0, BUFF_SIZE * sizeof(long));
                }
            }
            buff[idx] |= val << bitofs;
        }
#endif
#ifdef VERBOSE
        PrintBin(psize, val);
        putchar(' ');
        /*puts("");*/
#endif

        f[0] = 0;
        A[j] += (char)D[j];
        if ((0 == A[j]) || (A[j] == (char)(psize -j)))
        {
            D[j] = -D[j];
            f[j] = f[j+1];
            f[j+1] = (char)(j+1);
        }
    } while (j < psize);

#ifndef TEST
    if (1 != fwrite((void *)buff, (idx +1) * sizeof(long), 1, fp))
    {
        fprintf(stderr, "Errore durante la scrittura sul file %s!\n", fname);
        fclose(fp);
        exit(ERR_WRITE);
    }

    if (0 == fseek(fp, sizeof(size_t), SEEK_SET))
    {
        fwrite((void *)&perms, sizeof(size_t), 1, fp);
    }
    else
    {
        fprintf(stderr, "Errore durante la scrittura sul file %s!\n", fname);
        fclose(fp);
        exit(ERR_WRITE);
    }
    fclose(fp);

    printf("Totale: %lu permutazioni compresse in %lu codici, %lu bytes.\n",
           perms * n, perms, Words << 2);
#endif
}
/* EOF: HRW_gen.c */

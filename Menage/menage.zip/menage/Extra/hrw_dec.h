/*************************************************************************
**************************************************************************
**                                                                      **
**  PROGRAMMA......:  HRW_dec.h                                         **
**  AUTORE.........:  M.A.W. 1968                                       **
**  LICENZA........:  Public Domain                                     **
**  DATA...........:  22/08/2015            Ore 00:35                   **
**  VERSIONE.......:  1.0                                               **
**                                                                      **
**  Descrizione....:  Header privato di HRW_dec.c                       **
**                                                                      **
**************************************************************************
*************************************************************************/

#ifndef __HRW_DEC_H__
#define __HRW_DEC_H__

#include "hrw_shared.h"

/************************************************************************/

#define FNAME_SIZE 128
#define LINE_WIDTH  80

#define MAX_SIZE_DECODED 9

uint buff[BUFF_SIZE];

/*
** Nodo della lista che descrive una permutazione.
*/
typedef struct node {
    struct node *next;
    BYTE data;
} Node_t;

/*
** Struttura di gestione della lista linkata semplice.
*/
struct {
    Node_t *current;    /* Puntatore al penultimo nodo, fondamentale! */
    Node_t *first;
    Node_t *last;
    size_t Items;
} ListHead;

/* Costanti figurative per i codici di errore restituiti al sistema */
enum {ERR_NONE, ERR_ARGS, ERR_OPEN, ERR_SIZE, ERR_INVALID, ERR_READ};

/************************************************************************/
/************************************************************************/
/* Ottiene la dimensione di un file aperto */
size_t GetFileSize(FILE *st);
/* Stampa in base binaria i 32 bit meno significativi di val */
void PrintBin(const size_t n, const size_t val);

/* Aggiunge un nodo in coda alla LLS */
boole_t AppendNode(const BYTE val);
/* Scambia il nodo corrente con l'ultimo o il penultimo */
void ShiftNode(const boole_t swap);
/* Stamp l'intera lista (che rappresenta una permutazione) */
void PrintLLS(void);
/* Inizializza la LLS come richiesto dall'algoritmo */
void InitLLS(BYTE n);
/* Dealloca i nodi della lista al termine del lavoro */
void CleanLLS(void);
/************************************************************************/
/************************************************************************/

#endif
/* EOF: HRW_dec.h */

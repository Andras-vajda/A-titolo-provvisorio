/*************************************************************************
**************************************************************************
**                                                                      **
**  PROGRAMMA......:  HRW_gen.h                                         **
**  AUTORE.........:  M.A.W. 1968                                       **
**  LICENZA........:  Public Domain                                     **
**  DATA...........:  22/08/2015            Ore 00:35                   **
**  VERSIONE.......:  1.0                                               **
**                                                                      **
**  Descrizione....:  Header privato di HRW_gen.c                       **
**                                                                      **
**************************************************************************
*************************************************************************/

#ifndef __HRW_GEN_H__
#define __HRW_GEN_H__

#include "hrw_shared.h"

/************************************************************************
** La massima ampiezza teorica trattabile in questa implementazione e'
** volutamente limitata a CHAR_BIT * sizeof(unsigned int), ovvero 32
** sulle comuni macchine wintel x86.
** Tuttavia, sconsiglio formalmente di tentare generazioni esaustive
** di tale ampiezza... l'idea rimane solo quella di illustrare un ottimo
** algoritmo e mostrare come superare i limiti delle implementazioni
** basate sul calcolo esplicito del fattoriale con i tipi nativi del C.
*************************************************************************/

#define PERM_SIZE 5

/* Costanti figurative per i codici di errore restituiti al sistema */
enum {ERR_NONE, ERR_CREATE, ERR_WRITE};

/************************************************************************/
void PrintBin(const size_t n, const size_t val);
void BinaryBell(const BYTE n);
/************************************************************************/

/* Buffer di output su file binario */
uint buff[BUFF_SIZE];

/* Array specifici per l'algoritmo HRW */
char A[PERM_MAX];
char f[PERM_MAX];
int  D[PERM_MAX];

#endif
/* EOF: HRW_gen.h */

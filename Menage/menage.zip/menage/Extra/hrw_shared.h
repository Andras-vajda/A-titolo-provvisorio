/*************************************************************************
**************************************************************************
**                                                                      **
**  PROGRAMMA......:  HRW_shared.h                                      **
**  AUTORE.........:  M.A.W. 1968                                       **
**  LICENZA........:  Public Domain                                     **
**  DATA...........:  22/08/2015            Ore 00:35                   **
**  VERSIONE.......:  1.0                                               **
**                                                                      **
**  Descrizione....:  Header condiviso per HRW_gen.c e HRW_dec.c        **
**                                                                      **
**************************************************************************
*************************************************************************/

#ifndef __HRW_SHARED_H__
#define __HRW_SHARED_H__

#include <stdio.h>
#include <stdlib.h>
#include <limits.h>
#include <assert.h>
#include <string.h>
#include <ctype.h>

/**************************************************************/

#define H_SEP_STAR "********************************************************************************"
#define H_SEP_LINE "--------------------------------------------------------------------------------"

#define str(x) # x
#define xstr(x) str(x)

#define FINGERPRINT 0x00575248L
#define FP_MASK     0x00FFFFFFL
/*#define BUFF_SIZE   1024*/
#define BUFF_SIZE   USHRT_MAX
#define PERM_MIN    4
#define PERM_MAX    32

/**************************************************************/

typedef unsigned char       BYTE;
typedef unsigned int        uint;
typedef enum {FALSE, TRUE}   boole_t;

/**************************************************************/

/* Header per il file dati */
struct {
    uint  FingerPrint;
    uint  NumPerms;
} HRW_header;

#endif
/* EOF: HRW_shared.h */

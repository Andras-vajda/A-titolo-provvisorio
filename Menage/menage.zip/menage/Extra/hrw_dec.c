/*************************************************************************
**************************************************************************
**                                                                      **
**  PROGRAMMA......:  HRW_dec.c                                         **
**  AUTORE.........:  M.A.W. 1968                                       **
**  LICENZA........:  Public Domain                                     **
**  DATA...........:  22/08/2015            Ore 00:35                   **
**  VERSIONE.......:  1.0                                               **
**                                                                      **
**  Descrizione....:  Originale implementazione esemplificativa di un   **
**  decoder per file prodotti con HRW_gen (Hollroyd, Ruskey, Williams)  **
**  per la generazione di permutazioni con ordinamento "BellRinger".    **
**                                                                      **
**************************************************************************
*************************************************************************/

#include "hrw_dec.h"

/************************************************************************/
/************************************************************************/
int main(int argc, char **argv)
{
    FILE *fp;
    char fname[FNAME_SIZE];
    size_t datasize, res;

    if (argc != 2)
    {
        fprintf(stderr, "USO: %s nome_file.dat\n", argv[0]);
        return (ERR_ARGS);
    }
    else
    {
        strncpy(fname, argv[1], FNAME_SIZE -1);
    }

    fprintf(stderr, "Apertura del file \"%s\".\n", fname);

    fp = fopen(fname, "rb");
    if (NULL == fp)
    {
        fprintf(stderr, "Errore durante l'apertura del file %s!\n", fname);
        return ERR_OPEN;
    }

    /* Dimensione dei soli dati, a meno dello header */
    datasize = GetFileSize(fp) - sizeof(HRW_header);

    res = fread((void *)&HRW_header, sizeof(HRW_header), 1, fp);
    if (1 != res)
    {
        fprintf(stderr, "Errore durante la lettura dal file %s!\n", fname);
        fclose(fp);
        return ERR_READ;
    }

    if (0 == ((HRW_header.FingerPrint & FP_MASK) ^ FINGERPRINT))
    {
        BYTE bitofs;        /* Offset corrente entro la word     */
        BYTE csize;         /* Dimensione della permutazione     */
        BYTE ppl;           /* Permutazioni per riga, a video    */
        size_t mask;        /* Bitmask per unpacking dei bit     */
        size_t i = 0;       /* Variabile di induzione            */
        size_t perms = 0;   /* Numero di permutazioni codificate */
        size_t Tot   = 0;   /* Numero totale di permutazioni     */

        csize = (BYTE)(((HRW_header.FingerPrint & ~FP_MASK) >> 24) -2);

        if ((csize +2) > MAX_SIZE_DECODED)
        {
            fprintf(stderr, "Per motivi pratici, questo dimostrativo consente di decodificare\n"
                    "solo permutazioni di ampiezza non superiore a "
                    xstr(MAX_SIZE_DECODED) ".\n\n");

            return(ERR_SIZE);
        }

        bitofs = CHAR_BIT * sizeof(long);   /* Tipicamente 32 */
        mask   = (1 << csize) -1;
        ppl    = (BYTE)(LINE_WIDTH / (csize +3));

        fprintf(stderr, "Permutazioni di ampiezza %d: %lu codici, %lu bytes.\n",
               csize +2, HRW_header.NumPerms, datasize);

        InitLLS((BYTE)(csize +2));

        puts(H_SEP_LINE);

        res = fread((void *)buff, datasize, 1, fp);
        if (1 != res)
        {
            fprintf(stderr, "Errore durante la lettura dal file %s!\n", fname);
            fclose(fp);
            return ERR_READ;
        }

        do
        {
            short delta;
            size_t bmask;
            size_t byte = 0;

            ++perms;

            delta  = (short)(bitofs - csize);
            bitofs = (BYTE)((CHAR_BIT * sizeof(long) -1) & (delta));

            if (delta < 0)
            {
                if (0 != bitofs)
                {
                    byte = (buff[i] << -delta) & mask;
                }
                ++i;
            }

            byte |= (buff[i] >> bitofs) & mask;

#ifdef VERBOSE
            PrintBin(csize, byte);
            puts("");
#endif
            for (bmask = 1 << (csize +1); bmask > 0; bmask >>= 1)
            {
                PrintLLS();
                ShiftNode((boole_t)(byte & bmask));
                ++Tot;
#ifndef VERBOSE
                if (0 == (Tot % ppl))
                {
                    puts("");
                }
#endif
            }
        } while (perms < HRW_header.NumPerms);

        puts("\n" H_SEP_LINE);
        fprintf(stderr, "Totale: %lu permutazioni decodificate.\n\n", Tot);

    }
    else
    {
        fprintf(stderr, "Il file %s e' corrotto o non e' stato prodotto"
                " con HRW_gen!\n", fname);
        fclose(fp);
        return ERR_INVALID;
    }

    CleanLLS();
    fclose(fp);
    return ERR_NONE;
}
/************************************************************************/
/************************************************************************/

/************************************************************************/
/*
** Sposta il primo nodo in coda alla permutazione.
** Il parametro booleano gestisce la effettiva posizione (ultima o
** penultima), come richiesto dall'algoritmo specifico.
*/
/************************************************************************/
void ShiftNode(const boole_t swap)
{
    if (ListHead.Items > 2)
    {
        if (swap)
        {
            (ListHead.current)->next = ListHead.first;
            ListHead.current = ListHead.first;
            ListHead.first   = (ListHead.current)->next;
            (ListHead.current)->next = ListHead.last;
        }
        else
        {
            (ListHead.last)->next = ListHead.first;
            ListHead.current = ListHead.last;
            ListHead.last    = ListHead.first;
            ListHead.first = (ListHead.first)->next;
            (ListHead.last)->next = NULL;
        }
    }
}

/************************************************************************/
/*
** Stampa l'intera lista (permutazione).
*/
/************************************************************************/
void PrintLLS(void)
{
#ifdef DEBUG
    size_t i = 1;
#endif
    Node_t *p;

    if (0 == ListHead.Items)
    {
        return;
    }

#ifdef DEBUG
    printf("List start.......: %d\n"
           "Last node........: %d\n"
           "Current ptr......: %d\n",
           (ListHead.first)->data,
           (ListHead.last)->data,
           (ListHead.current)->data);

    for (p = ListHead.first; p != NULL; p = p->next)
    {
        printf("%2d: val = %d\n", i++, p->data);
    }
#else
    for (p = ListHead.first; p != NULL; p = p->next)
    {
        printf("%d", p->data);
    }
    putchar(' ');
#endif
}

/************************************************************************/
/*
** Aggiunge un nodo in coda della lista.
*/
/************************************************************************/
boole_t AppendNode(const BYTE val)
{
    Node_t *p;
    boole_t retval = FALSE;

    p = (Node_t *)malloc(sizeof(Node_t));
    if (NULL != p)
    {
        retval = TRUE;

        p->data = val;
        p->next = NULL;

        ListHead.Items += 1;
        if (1 == ListHead.Items)
        {
            ListHead.first   = p;
            ListHead.current = p;
            ListHead.last    = p;
        }
        else
        {
            ListHead.current         = ListHead.last;
            ListHead.last            = p;
            (ListHead.current)->next = p;
        }
    }

    return retval;
}

/************************************************************************/
/*
** Inizializza la lista che rappresenta la permutazione.
*/
/************************************************************************/
void InitLLS(BYTE n)
{
    BYTE i;

    ListHead.current = NULL;
    ListHead.first   = NULL;
    ListHead.last    = NULL;
    ListHead.Items   = 0;

    /*
    ** I nodi vengono aggiunti nell'ordine iniziale richiesto
    ** dall'algoritmo: n n-1 ... 3 2 1
    */
    for (i = n; i > 0; --i)
    {
        AppendNode(i);
    }

#ifdef DEBUG
    puts(H_SEP_STAR);
    PrintLLS();
    puts(H_SEP_STAR);
#endif
}

/************************************************************************/
/*
** Dealloca i nodi della lista al termine del lavoro.
*/
/************************************************************************/
void CleanLLS()
{
    Node_t *p, *q;

    p = ListHead.first;

    do
    {
        q = p;
        p = p->next;
        free(q);
    } while (NULL != p);
}
/************************************************************************/
/*
** Ottiene la dimensione di un file (aperto)
*/
/************************************************************************/
size_t GetFileSize(FILE *st)
{
   size_t curpos, len;

   curpos = (size_t)ftell(st);
   fseek(st, 0L, SEEK_END);
   len = (size_t)ftell(st);
   fseek(st, curpos, SEEK_SET);

   return len;
}

/************************************************************************/
/*
** Stampa il valore binario di un intero non segnato, limitato
** agli n bit meno significativi (max 32).
*/
/************************************************************************/
void PrintBin(const size_t n, const size_t val)
{
    size_t mask;

    for (mask = 1 << (n -1); mask > 0; mask >>= 1)
    {
       printf("%c", (val & mask ? '1' : '0'));
    }
}
/* EOF: HRW_perm.c */

/*************************************************************************
**************************************************************************
**                                                                      **
**  PROGRAMMA......:  Derange_ER.h                                      **
**  AUTORE.........:  M.A.W. 1968                                       **
**  LICENZA........:  Public Domain                                     **
**  DATA...........:  22/08/2015            Ore 00:35                   **
**  VERSIONE.......:  1.0                                               **
**                                                                      **
**  Descrizione....:  Header privato di Derange_ER.c                    **
**                                                                      **
**************************************************************************
*************************************************************************/

#ifndef __DERANGE_ER_H__
#define __DERANGE_ER_H__

#include "derange.h"

/*
** Disabilitare per eliminare l'output a video dei derangements.
*/
#define VERBOSE

/*
** Strutture di supporto a ER_derange():
** consentono la gestione della LLS che contiene l'insieme dei valori non
** ancora utilizzati durante la costruzione della permutazione corrente.
*/
typedef struct node
{
    struct node *next;
    uint8_t     data;
} Node_t;

typedef struct
{
    Node_t *first;      /* Puntatore al primo nodo                     */
    Node_t *last;       /* Puntatore all'ultimo nodo                   */
    Node_t **stack;     /* Lista secondaria per il riciclo dei nodi    */
    size_t Items;       /* Numero di elementi in lista                 */
    size_t Avail;       /* Elementi in coda per il riciclo             */
} ListHead_t;

/************************************************************************/
/************************************************************************/
/* Algoritmo ricorsivo di Effler e Ruskey per la generazione di         */
/* permutazioni, modificato per generare solo i derangements.           */
uint_t ER_derange(const uint8_t n, const uint8_t k);

/* Restituisce il coefficiente binomiale n su k.                        */
uint_t BinCoef(int n, int k);

/*
** Funzioni di supporto a ER_derange():
** consentono la gestione della LLS che contiene l'insieme dei
** valori non ancora utilizzati durante la costruzione della
** permutazione corrente.
*/
Boole_t AppendNode(uint8_t val);
Boole_t InsertNode(uint8_t pos, uint8_t val);
Boole_t PeekNode(uint8_t pos, uint8_t *v);
Boole_t InitLLS(size_t si, uint8_t ofs);
void RemoveNode(void);
void CleanLLS(void);
/************************************************************************/
/************************************************************************/

#endif
/* EOF: Derange_ER.h */
/*************************************************************************
**************************************************************************
**                                                                      **
**  PROGRAMMA......:  Misc_ER.c                                         **
**  AUTORE.........:  M.A.W. 1968                                       **
**  LICENZA........:  Public Domain                                     **
**  DATA...........:  22/08/2015            Ore 00:35                   **
**  VERSIONE.......:  1.0                                               **
**                                                                      **
**  Descrizione....:  Funzioni di supporto a Derange_ER.c, gestione     **
**  della LLS con "dancing links".                                      **
**                                                                      **
**************************************************************************
*************************************************************************/

#include "derange_ER.h"

extern ListHead_t ListHead;

/************************************************************************/
/* Funzione di supporto a ER_derange():                                 */
/* popolazione iniziale della LLS che rappresenta l'insieme dei valori  */
/* ancora disponibili per formare la corrente permutazione.             */
/* Richiama AppendNode().                                               */
/************************************************************************/
Boole_t InitLLS(size_t si, uint8_t ofs)
{
    size_t i;
    Node_t *p;

    /* Dummy node preiniziale, consente di evitare molte eccezioni */
    p = (Node_t *)malloc(sizeof(Node_t));
    if (NULL == p)
    {
        fprintf(stderr, "Errore di allocazione!\n\n");
        return FALSE;
    }
    p->data = 0xFF;
    p->next = NULL;

    /* Stack per i nodi temporaneamente eliminati */
    ListHead.stack = (Node_t**)malloc(si * sizeof(Node_t*));
    if (NULL == ListHead.stack)
    {
        fprintf(stderr, "Errore di allocazione!\n\n");
        return FALSE;
    }

    ListHead.first   = p;
    ListHead.last    = p;
    ListHead.Items   = 0;
    ListHead.Avail   = 0;

    for (i = 0; i < si; ++i)
    {
        AppendNode(i + ofs);
    }

    return TRUE;
}

/************************************************************************/
/* Funzione di supporto a ER_derange():                                 */
/* aggiunge un nodo in coda alla lista. Usata per la popolazione        */
/* iniziale della LLS che rappresenta l'insieme dei valori ancora       */
/* disponibili per formare la corrente permutazione (derangement).      */
/************************************************************************/
Boole_t AppendNode(uint8_t val)
{
    Node_t *p;
    Boole_t retval = FALSE;

    p = (Node_t *)malloc(sizeof(Node_t));
    if (NULL != p)
    {
        p->data = val;
        p->next = NULL;

        ListHead.Items += 1;
        (ListHead.last)->next = p;
        ListHead.last = p;

        retval = TRUE;
    }

    return retval;
}

/************************************************************************/
/* Cleanup finale della LLS e strutture dati associate.                 */
/************************************************************************/
void CleanLLS()
{
    Node_t *p, *q;

    p = ListHead.first;

    do
    {
        q = p;
        p = p->next;
        free(q);
    } while (NULL != p);

    free(ListHead.stack);
}
/* EOF: Derange_ER.c */

/*************************************************************************
**************************************************************************
**                                                                      **
**  PROGRAMMA......:  Derange_ER.c                                      **
**  AUTORE.........:  M.A.W. 1968                                       **
**  LICENZA........:  Public Domain                                     **
**  DATA...........:  22/08/2015            Ore 00:35                   **
**  VERSIONE.......:  1.0                                               **
**                                                                      **
**  Descrizione....:  Originale implementazione di un algoritmo per la  **
**  generazione di derangements, basato su un recente lavoro del ben    **
**  noto professor Ruskey per la generazione di permutazioni con un     **
**  dato numero di inversioni.                                          **
**************************************************************************
**  Scott Effler, Frank Ruskey, "A CAT Algorithm for Generating         **
**  Permutations with a Fixed Number of Inversions", Information        **
**  Processing Letter 86-2 (2003) 107-112.                              **
**                                                                      **
**************************************************************************
*************************************************************************/

#include "derange_ER.h"

/* Variabili globali */
Derange_MT Derange;
ListHead_t ListHead;

/************************************************************************/
/************************************************************************/
int main(int argc, char **argv)
{
    size_t i;
    uint_t tot;

    /* Impostazione del default */
    Derange.Width = DERANGE_WIDTH;
    assert(Derange.Width < MAX_DERANGE);

    if (2 == argc)
    {
        uint8_t t = (uint8_t)atoi(argv[1]);
        if ((t > 2) && (t < MAX_DERANGE))
        {
            Derange.Width = t;
        }
        else
        {
            fprintf(stderr, "Errore nel parametro da command line [%s]!\n\n",
                    argv[1]);
        }
    }

    /************************************************************************/
    printf("\nDerangements di %d (%lu), algoritmo di Effler-Ruskey,\n"
           "in ordine crescente di numero di inversioni:\n",
           Derange.Width, De[Derange.Width]);

    if (!InitLLS(Derange.Width, 0))
    {
        return (1);
    }

    tot = 0;

    /* I limiti di induzione derivano dalle note proprieta' dei derangements */
    for (i = (Derange.Width & 1) + (Derange.Width >> 1);
         i <= BinCoef(Derange.Width, 2) -(Derange.Width & 1); ++i)
    {
#ifdef VERBOSE
        printf(" %2d:\t", i);
#endif
        /* Implementazione dell'algoritmo ricorsivo di Effler e Ruskey */
        tot += ER_derange(Derange.Width, i);
#ifdef VERBOSE
        puts("");
#endif
    }
#ifdef VERBOSE
    printf("** Totale: %lu **\n", tot);
#endif

    CleanLLS();

    return EXIT_SUCCESS;
}

/************************************************************************/
/* Algoritmo ricorsivo di Effler e Ruskey per la generazione di         */
/* permutazioni, modificato per generare solo i derangements.           */
/* L'interesse di questa implementazione consiste nel particolare       */
/* ordine di generazione, per numero di inversioni k.                   */
/************************************************************************/
uint_t ER_derange(const uint8_t n, const uint8_t k)
{
    /*
    ** Al termine della ricorsione, cnt contiene il totale dei
    ** derangements generati:
    */
    uint_t cnt = 0;

    size_t j;
    Node_t *ptr = ListHead.first;

    if ((0 == n) && (0 == k))
    {
#ifdef VERBOSE
        DisplayVector(Derange.Width, Derange.D, "", "  ", "");
#endif
        ++cnt;
    }
    else
    {
        size_t lim, w = 0;
        /*
        ** Il calcolo dei limiti per j in funzione dei vincoli imposti a k
        ** consente di eliminare la if() dal loop principale rispetto allo
        ** pseudocodice proposto nell'articolo.
        ** Si esplicita il precalcolo del limite massimo in funzione di k ed n,
        ** per evitare potenziali valutazioni multiple nel binario prodotto.
        */
        j = max(n -k -1, 0);
        lim = min((BinCoef(n -1, 2) + n -k), n);
        /* Posizionamento iniziale nella LLS */
        for (w = 0; w < j; ++w)
        {
            ptr = ptr->next;
        }
        for (; j < lim; ++j)
        {
            /*
            ** Si noti la facilita' estrema con la quale l'algoritmo viene
            ** modificato per generare solo derangements.
            */
            if (ptr->next->data != n -1)
            {
                Derange.D[n -1] = ptr->next->data;
                /* PushNode(ptr->next); */
                ListHead.stack[ListHead.Avail++] = ptr->next;
                ptr->next = ptr->next->next;
                cnt += ER_derange(n -1, k + j -n +1);
                /* ptr->next = PopNode(); */
                ptr->next = ListHead.stack[--ListHead.Avail];
            }
            ptr = ptr->next;
        }
    }

    return cnt;
}
/* EOF: Derange_ER.c */
